const Cards = [
    {
        id: "1",
        img: "./images/kimano.png",
        title: "Кимано",
        text: "Костюм для Карате"
    },
    {
        id: "2",
        img: "./images/dobok.png",
        title: "Добок",
        text: "Костюм для тхэквондо"
    },
    {
        id: "3",
        img: "./images/paw.png",
        title: "Лапа для битья",
        text: "Подходит для любого боевого вида спорта"
    }
]
export default Cards;