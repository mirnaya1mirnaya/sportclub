const Cards = [
    {
        id: "1",
        img: "./images/gantely.png",
        title: "Тренажер",
        text: "Для спины и плеч"
    },
    {
        id: "2",
        img: "./images/begovaya.png",
        title: "Беговая дорожка",
        text: "Беговая дорожка для умеренного бега"
    },
    {
        id: "3",
        img: "./images/velotrenager.png",
        title: "Велотренажер",
        text: "Хорошо прокачает ваши ноги и выносливость"
    }
]
export default Cards;