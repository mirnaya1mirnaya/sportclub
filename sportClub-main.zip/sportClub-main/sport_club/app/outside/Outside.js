const Cards = [
    {
        id: "1",
        img: "./images/palki.jpg",
        title: "Палки для треккинга",
        text: "Приятная ходьба вам обеспечена."
    },
    {
        id: "2",
        img: "./images/velosiped.png",
        title: "Велосипед",
        text: "Надежный напарник в вашем пути!"
    },
    {
        id: "3",
        img: "./images/cross.png",
        title: "Кроссовки",
        text: "Стельки, которые рекомендуют врачи."
    }
]
export default Cards;