const Cards = [
    {
        id: "1",
        img: "./images/palki.jpg",
        title: "Палки для треккинга",
        text: "Приятная ходьба вам обеспечена."
    },
    {
        id: "2",
        img: "./images/poker.png",
        title: "Карты",
        text: "Не для активного отдыха, помогут вам расслабится."
    },
    {
        id: "3",
        img: "./images/begovaya.png",
        title: "Беговая дорожка",
        text: "Беговая дорожка для умеренного бега"
    }
]
export default Cards;