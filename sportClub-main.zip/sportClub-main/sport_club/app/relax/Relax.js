const Cards = [
    {
        id: "1",
        img: "./images/mono.jpg",
        title: "Моноцикл",
        text: "Обеспечит веселое времяпрепровождение с вашими друзьями"
    },
    {
        id: "2",
        img: "./images/poker.png",
        title: "Карты",
        text: "Не для активного отдыха, помогут вам расслабится."
    },
    {
        id: "3",
        img: "./images/free.png",
        title: "Фрисби",
        text: "Тарелка для метания"
    }
]
export default Cards;